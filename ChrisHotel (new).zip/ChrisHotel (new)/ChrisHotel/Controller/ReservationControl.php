<?php
class ReservationControl{
    public function __construct(){
    }
}